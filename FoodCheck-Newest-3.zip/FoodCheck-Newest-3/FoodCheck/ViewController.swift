//
//  ViewController.swift
//  FoodCheck
//
//  Created by Sana Tipnis on 3/28/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

